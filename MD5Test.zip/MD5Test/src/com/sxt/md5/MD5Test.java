package com.sxt.md5;

import java.util.Scanner;

import com.sxt.utils.MD5;

public class MD5Test {
	public static void main(String[] args) {
		String pwd = MD5.getData("longlife");
		System.out.println(pwd);
		
		System.out.println("输入密码:");
		String password=new Scanner(System.in).next();
		if(pwd.equals(MD5.getData(password))){
			System.out.println("密码输入正确");
		}
	}
}
